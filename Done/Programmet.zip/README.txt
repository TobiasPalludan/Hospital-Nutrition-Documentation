For at compilere programmet skal man i sin MinGW indtaste ordet "make" for at compile p� en windows computer. 
Dermed compileres og k�res programmet, hvorefter det er muligt for brugeren at bruge programmet. 

Der bliver p� standardoutput vist en r�kke handlinger som brugeren kan udf�re. 
For at udf�re handlingerne skal brugeren indtaste det tal som tilsvarer handlingen. 

Der er i forvejen oprettet en patient # 1, som kan tilg�es gennem programmet og som kan ses i mappen patients/1.

For at se hvilke madvarer der findes i Nutritional_database skal den tilg�es manuelt. 

Programmets funktion er at give brugeren muligheden, for at kunne opbevare information om en person, f.eks. en patient, i en slags database best�ende af sorterede mapper med filer i. 
Brugeren har s� muligheden for at tilg� en bestemt m�ngde af information om en bestemt person via input i MinGW under programmets runtime. 
Mapperne bliver lavet i den samme sti som 
programmet ligger i.