
/*Lib.c prototypes*/
double BMI(double height, double weight);
double BMR(double height, double weight, long long int cpr);
int get_age(long long int cpr);
void datestamp(char output[]);
void print_warning(double BMI);
int warning_BMI(double BMI);
